<template>
<div class="row " id="mydiv">
    <div class="card w-50">
        <div class="card-body">
            <h5 class="card-title">User's information</h5>
            <p class="card-text">
                Name: Ali<br>
                Email: ali@gmaom.com

            </p>
            <a href="#" class="btn btn-primary">Update</a>
            <a href="#" class="btn btn-primary">Delate</a>
        </div>
    </div>


</div>
  
</template>



<script>





</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
