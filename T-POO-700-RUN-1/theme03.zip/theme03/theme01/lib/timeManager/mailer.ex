defmodule Todolist.Mailer do
  use Swoosh.Mailer, otp_app: :timeManager
end
