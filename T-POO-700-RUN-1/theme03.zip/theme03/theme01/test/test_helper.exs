ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Todolist.Repo, :manual)
