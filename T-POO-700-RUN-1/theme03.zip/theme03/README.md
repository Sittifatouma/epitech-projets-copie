# Todolist

To start the servers:

  * docker-compose build
  * docker-compose up

Now you can visit [`localhost:4000`](http://localhost:4000) for the back end service
                  [`localhost:8080`](http://localhost:8080) for the front end service




