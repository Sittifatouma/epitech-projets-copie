<template>
    <h1>logout</h1>
</template>
<script>
export default {
    name:"Logout",
    
}
</script>
<style  scoped>

</style>
