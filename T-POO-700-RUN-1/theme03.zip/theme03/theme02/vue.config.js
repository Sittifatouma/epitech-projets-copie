module.exports = {
    devServer: {
      proxy: 'http://localhost:4000'
    }
  }